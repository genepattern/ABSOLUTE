### R code from vignette source 'optparse.Rnw'

###################################################
### code chunk number 1: optparse.Rnw:10-15
###################################################
Rscript_executable <- file.path(R.home(), "bin", "Rscript")
setwd(system.file("exec", package="optparse")) # to access the "Rscript files"
list_file_command <- "ls"
chmod_command <- "chmod ug+x display_file.R example.R"
path_command <- "export PATH=$PATH:`pwd`"


###################################################
### code chunk number 2: optparse.Rnw:21-23
###################################################
cat(system(sprintf("%s", list_file_command), intern=TRUE), sep="\n")
command <- "display_file.R example.R" # to show file


###################################################
### code chunk number 3: optparse.Rnw:37-38
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   


###################################################
### code chunk number 4: optparse.Rnw:42-43
###################################################
command <- "example.R --help" # same as system("Rscript example.R -h")


###################################################
### code chunk number 5: optparse.Rnw:49-51
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "example.R" # rely only on defaults


###################################################
### code chunk number 6: optparse.Rnw:57-59
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "example.R --mean=10 --sd=10 --count=3" 


###################################################
### code chunk number 7: optparse.Rnw:66-68
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "example.R --quiet -c 4 --generator=\"runif\"" #  same as above but "quiet"


###################################################
### code chunk number 8: optparse.Rnw:76-78
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "example.R --silent -m 5" #  same as above but "quiet"


###################################################
### code chunk number 9: optparse.Rnw:84-86
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "example.R -c 100 -c 2 -c 1000 -c 7" #  same as above but "quiet"


###################################################
### code chunk number 10: optparse.Rnw:92-93
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   


###################################################
### code chunk number 11: optparse.Rnw:98-99
###################################################
command <- "display_file.R --help" 


###################################################
### code chunk number 12: optparse.Rnw:102-104
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "display_file.R --add_numbers display_file.R" 


###################################################
### code chunk number 13: optparse.Rnw:107-109
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "display_file.R non_existent_file.txt" 


###################################################
### code chunk number 14: optparse.Rnw:112-114
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   
command <- "display_file.R"


###################################################
### code chunk number 15: optparse.Rnw:118-119
###################################################
cat(system(sprintf("%s %s 2>&1", Rscript_executable, command),  intern=TRUE), sep="\n")   


